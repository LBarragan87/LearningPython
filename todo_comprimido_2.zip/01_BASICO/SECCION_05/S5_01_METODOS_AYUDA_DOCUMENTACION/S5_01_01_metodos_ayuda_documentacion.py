dic = {"clave1":100,"clave2":500}
print(dic)
popped=dic.popitem()
print (popped)
print (dic)
