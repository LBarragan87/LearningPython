'''
Declara una función llamada saludar, que cada vez que sea llamada imprima en pantalla "¡Hola mundo!"

Solo debes definir la función, no debes invocarla luego.
'''

def saludar():
    print("¡Hola mundo!")

saludar()
