def mi_funcion():
    ''''
    descripcion de lo que hace la funcion
    '''
    print ("hola")
    
mi_funcion()

def saludo(usuario):
    '''
    funcion que salude a usuario
    '''
    print (f"hola {usuario}")
    
saludo("Luis")
saludo(input("ingresa tu nombre: "))