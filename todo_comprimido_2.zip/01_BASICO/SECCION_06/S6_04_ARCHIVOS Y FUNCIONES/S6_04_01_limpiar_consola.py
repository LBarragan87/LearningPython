import os
import time
os.system('cls')
nombre=input("ingresa tu nombre: ")
apellido=input("ingresa tu apellido:")
os.system('cls')
print(f"bienvenido {nombre} {apellido}")