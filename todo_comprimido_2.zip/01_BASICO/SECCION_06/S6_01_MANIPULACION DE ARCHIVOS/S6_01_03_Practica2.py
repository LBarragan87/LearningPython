'''
Imprime la primera línea del archivo texto.txt

No olvides abrir el archivo y cerrarlo luego de ejecutar tu código.

Nota: el archivo se encuentra guardado en la misma carpeta donde se aloja tu código
'''
mi_archivo=open("archivo_ejercicios_seccion1_ejercicio1.txt")
print(mi_archivo.readline().rstrip())