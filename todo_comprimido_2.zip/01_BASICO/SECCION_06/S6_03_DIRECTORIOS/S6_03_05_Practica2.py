'''
Implementa y crea una ruta relativa que nos permita llegar al archivo "practicas_path.py" a partir de la siguiente estructura de carpetas:

curso python->dia 6 -> practicas_path.py
Almacena el directorio obtenido en la variable ruta. No olvides importar Path.
'''
from pathlib import Path
ruta=Path("Curso Python","Día 6","practicas_path.py")