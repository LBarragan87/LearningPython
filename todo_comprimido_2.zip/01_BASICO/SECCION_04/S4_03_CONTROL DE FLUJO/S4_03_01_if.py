if 10<9:
    print (f"10 es mayor que 9")
else:
    print (f"10 no es mayor que 9")
    
mascota = "perro"
if mascota == "gato":
    print ("tienes un gato")
elif mascota == "perro":
    print ("tienes un perro")
else:
    print("no se que animal tienes")
    
    
edad = 22
calificacion = 9
if edad<18:
    print ("eres menor de edad")
    if calificacion >=7:
        print("aprobado")
    else:
        print ("no aprobado")
        
else:
    print("eres adulto")
    