# operadores logicos "or (|)", "and" (&), "not"
# #identity operators "is", "is not"

prueba1 = (4<5) or (7<3)
print (prueba1)