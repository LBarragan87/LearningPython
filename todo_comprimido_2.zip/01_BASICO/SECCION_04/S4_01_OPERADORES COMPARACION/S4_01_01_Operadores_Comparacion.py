#comparadores
'''
>
<
<=
<=
==
!=
'''

mi_variable = "hola Mundo"
mi_bool = 10!=25
print (mi_bool)