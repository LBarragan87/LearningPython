#Crea un Loop While que se imprima en pantalla los números del 10 al 0, uno a la vez.

numero = 10

while numero >= 0:
    print(numero)
    numero  =numero-1