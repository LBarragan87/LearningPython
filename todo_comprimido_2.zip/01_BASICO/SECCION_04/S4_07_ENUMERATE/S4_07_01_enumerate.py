lista = ["a","b","c"]

for indice,item in enumerate(lista):
    print (indice,item)

nueva_lista=list(enumerate(lista))
print(nueva_lista)