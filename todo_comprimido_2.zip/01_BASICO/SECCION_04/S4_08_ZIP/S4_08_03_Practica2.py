#Crea un objeto zip formado a partir de listas, de un conjunto de marcas y productos que tú prefieras, dentro de la variable mi_zip.

marcas = ["a","e","i","o","u"]
productos =[1,2,3,4,5]
mi_zip=(zip(marcas,productos))
print (type(mi_zip))