lista = [1,2,3,4]

for numero in range(1,5):
    print (numero)