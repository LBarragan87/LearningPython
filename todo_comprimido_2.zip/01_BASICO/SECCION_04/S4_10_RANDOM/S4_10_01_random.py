from random import randint,random,uniform, choice

aleatorio_randint = randint(1,50)
aleatorio_uniform = uniform(1,50)
aleatorio_random = random()

print (aleatorio_randint,aleatorio_uniform,aleatorio_random)

colores = ["azul","rojo","verde","amarillo"]
color_choice=choice(colores)
print (color_choice)