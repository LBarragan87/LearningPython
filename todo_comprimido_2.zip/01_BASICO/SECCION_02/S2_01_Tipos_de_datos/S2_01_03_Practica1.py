'''
Declara dos variables, llamadas nombre y edad.

Asigna a la variable nombre el valor "Tony Soprano", y a la edad, el valor 51.
'''

nombre="Tony Soprano"
edad=51
print (f"{nombre} tiene {edad} años")