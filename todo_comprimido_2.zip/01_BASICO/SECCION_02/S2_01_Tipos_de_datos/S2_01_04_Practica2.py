'''
Crea tres variables:

nombre

apellido

nombrecompleto

A nombre, asígnale el valor "Julia", y en apellido, asigna el valor "Roberts". Finalmente, construye la variable nombrecompleto concatenando las variables (recuerda sumar un espacio intermedio).
'''

nombre="Julia"
apellido="Roberts"
nombrecompleto=f"{nombre} {apellido}"

print (nombrecompleto)