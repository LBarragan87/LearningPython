nombre = "luis"
print (nombre)

nombre = "eduardo"
print (nombre)

edad = 34
print (edad)
edad2 = 15
print (edad+edad2)

nombre = input ("dime tu nombre: ")
print (f"tu nombre es {nombre}")
