#string
str1 = "Hola"

#integer
int1 = 5

#floating
float1 = 3.1416

#list
list1 = [5,7.15,"martes"]

#diccionarios
dic1 = {"color" : "rojo", "dia":"martes", "mes" : "junio"}

#tuples
tuple1 = ("a","b","c")

#bool
bool1 = True