'''
Declara la variable curso, asígnale el valor "Python", y muestra en pantalla la frase:

Estás tomando un curso de curso

Para ello deberás concatenar la primera parte de la frase con el valor que asumirá la variable. Recuerda agregar un espacio antes de concatenar la variable al resto del texto.
'''

curso="Python"
print (f"Estás tomando un curso de {curso}")