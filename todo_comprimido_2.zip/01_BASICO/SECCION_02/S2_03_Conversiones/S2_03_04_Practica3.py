'''
Suma los valores de num1 y num2.

No modifiques el valor de las variables ya declaradas, sino aplica las conversiones necesarias dentro de la función print().
'''

num1 = "7.5"
num2 = "10"

print(float(num1) + float(num2))