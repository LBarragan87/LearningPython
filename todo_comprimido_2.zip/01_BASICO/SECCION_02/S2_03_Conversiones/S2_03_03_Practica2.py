#Convierte el valor de num2 en un float e imprime el tipo de dato que resulta:

num2 = 10
num1=float(num2)
print(num1)
print(type(num1))