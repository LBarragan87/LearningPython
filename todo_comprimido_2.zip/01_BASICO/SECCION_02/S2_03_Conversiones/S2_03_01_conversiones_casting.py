edad = 35

#int to string
edad_string=str(edad)
print (type(edad_string))

#string to int
valor = "25"
valor_int = int(valor)
print (type(valor_int))
print (valor_int)