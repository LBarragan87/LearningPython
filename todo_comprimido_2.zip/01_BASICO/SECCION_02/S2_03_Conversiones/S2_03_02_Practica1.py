#Convierte el valor de num1 en un int e imprime el tipo de dato que resulta:

num1 = 7.5
num2=int(num1)
print(type(num2))