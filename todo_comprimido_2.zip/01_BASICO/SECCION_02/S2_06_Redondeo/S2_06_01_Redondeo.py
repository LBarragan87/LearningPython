resultado = round(90/7)
print(resultado)

valor = 95.666666666666666666666666
print(round(valor,2))
print(type(round(valor,5)))