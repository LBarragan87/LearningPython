#Redondea el número 10.676767 al entero más próximo, y muestra en pantalla el resultado.

print(round(10.676767))