'''
regla 1: legible -> usar variables que describa que es 
regla 2: unidad ->no usar espacios / usar minusculas separadas por guines bajos
regla 3: hispanismos -> no usar acentos ni "ñ" / puede funcionar, pero evitar
regla 4: numeros -> la variable puede contener numeros, pero no puede iniciar con este
regla 5: signos -> no puede contener caracteres especiales (@ ! etc)
regla 6: no se pueden utilizar palabras clave


'''