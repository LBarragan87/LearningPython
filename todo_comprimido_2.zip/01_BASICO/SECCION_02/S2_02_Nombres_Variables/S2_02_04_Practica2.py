'''
Declara una variable numérica llamada num_decimal que contenga un valor de tipo float de tu elección.

Imprime el tipo de dato de dicha variable.
'''

num_decimal = 3.1416
print(type(num_decimal))