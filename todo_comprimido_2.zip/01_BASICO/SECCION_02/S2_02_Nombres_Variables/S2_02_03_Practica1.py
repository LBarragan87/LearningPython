'''
Declara una variable numérica llamada num_entero que contenga un valor de tipo integer de tu elección.

Imprime el tipo de dato de dicha variable.
'''
num_entero=35
print(type(num_entero))