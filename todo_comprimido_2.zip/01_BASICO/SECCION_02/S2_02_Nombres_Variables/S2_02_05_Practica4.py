'''
¿De qué tipo es el resultado de la suma de 7.5 + 2.5? Genera el código para verificarlo.

Para ello, crea dos variables:

num1 = 7.5

num2 = 2.5

A continuación, muestra en pantalla el tipo de dato que resulta de la suma de ambos números.

Realiza el mismo ejercicio en PyCharm para ver el resultado. ¿Coindice con lo que esperabas?
'''

num1=7.5
num2=2.5
suma = num1+num2
print(type(suma))