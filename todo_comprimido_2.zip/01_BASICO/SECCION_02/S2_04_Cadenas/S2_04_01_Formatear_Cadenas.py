x=10
y=5

print (f"mis numeros son: {x} y {y}")