'''
Necesitamos imprimir el nombre y número de asociado dentro de la siguiente frase:

Estimado/a (nombre_asociado), su número de asociado es: (numero_asociado)

Recuerda que la precisión de tu respuesta (espacios, ortografía y puntuación), es muy importante para llegar al resultado correcto.
'''

nombre_asociado = "Jesse Pinkman"
numero_asociado = 399058

print (f"Estimado/a {nombre_asociado}, su número de asociado es: {numero_asociado}")