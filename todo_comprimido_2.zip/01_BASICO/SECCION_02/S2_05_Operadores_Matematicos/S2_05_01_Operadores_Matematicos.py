x = 6
y=4

print (f"{x} mas {y} es igual a {x+y}")
print (f"{x} menos {y} es igual a {x-y}")
print (f"{x} por {y} es igual a {x*y}")
print (f"{x} entre {y} es igual a {x/y}")

print (f"{x} dividido al piso {y} es igual a {x//y}")
print (f"{x} modulo de {y} es igual a {x%y}")
print (f"{x} elevado a la  {y} es igual a {x**y}")
print (f"{x} al cubo es igual a {x**3}")
print (f"la raiz cuadrada de {x} es igual a {x**0.5}")