'''
Muestra en pantalla el cociente (división al piso) de los siguientes dos números: 874 dividido entre 27.

Debes mostrar solo el valor numérico que resulta de esta operación.
'''

print(874//27)