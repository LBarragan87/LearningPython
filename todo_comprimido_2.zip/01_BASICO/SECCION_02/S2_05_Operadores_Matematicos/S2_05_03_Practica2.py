'''
Muestra en pantalla el módulo (es decir, el resto) de la división entre 456 y 33.

Debes mostrar solo el valor numérico que resulta de esta operación.
'''

print(456%33)