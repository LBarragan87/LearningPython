'''
PROGRAMA UN RECETARIO
CONTENIDO INICIAL
    *CARPETA "RECETA", QUE CONTEENGA CARPETAS:
        -> CARNES: Y ARCHIVOS ETRECOT AL MALBEC.TXT / MATAMBRE A LA PIZZA.TXT
        -> ENSALADAS: Y ARCHIVOS ENSALADA GRIEGA.TXT/ENSALADA MEDITERRANEA.TXT
        -> PASTAS: CANELONES DE ESPINACA.TXT / RAVIOLES DE RICOTTA.TXT
        -> POSTRES: COMPOTA DE MANZANA.TXT / TARTA DE FRAMBUESA.TXT

interfaz
    - bienvenida al usuario
    - se indicara ruta de acceso a carpetas
    - se indicara el total de recetas disponibles
    - se solicitara seleccion de opciones
        * (1) leer receta -> elegir categoria -> mostrar recetas ->
                elegir receta -> leer receta
        * (2) crear receta -> elegir categoria -> crear nombre ->
                crear contenido
        * (3) crear categoria -> nombre de categoria -> crear carpeta
        * (4) eliminar receta -> elegir categoria -> mostrar recetas ->
                elegir receta -> elimina receta
        * (5) eliminar categoria -> elegir categoria -> se elimina categoria
        * (6) finalizar programa -> finalizar codigo

*** cada ocacion que el usuario realice exitosamente cualquier opcion,
    el programa debe pedir alguna letra para volver al inicio ()

*** cada ocacion que el usuario vuelva a la pantalla inicial,
    la consola se debe limpiar
'''
