mi_nombre = "Luis"
print (f"Me llamo {mi_nombre}")

print ("Esta es una linea \nEsta es la segunda linea \nEsta es la tercer linea")

print ("\tEste es un texto con sangria")