name= input ("Dime tu Nombre: ")
last_name = input ("Dime tu Apellido: ")

print(f"Hola {name} {last_name}") 