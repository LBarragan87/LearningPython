print ("Hola Mundo")
print (100+50)