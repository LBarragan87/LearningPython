mi_lista=list((1,1,1,1,2,2,3,3,3,3,5,5,2,4,5))
mi_set=set(mi_lista)
otro_set={1,1,1,1,2,2,3,3,3,3,5,5,2,4,5}

print(type(mi_lista))
print (mi_lista)

print(type(mi_set))
print (mi_set)

print(type(otro_set))
print (otro_set)
