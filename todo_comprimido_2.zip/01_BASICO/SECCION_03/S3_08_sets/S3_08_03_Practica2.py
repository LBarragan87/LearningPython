'''
Elimina un elemento al azar del siguiente set, utilizando métodos de sets.

sorteo = {"Camila", "Margarita", "Axel", "Jorge", "Miguel", "Mónica"}
'''

sorteo = {"Camila", "Margarita", "Axel", "Jorge", "Miguel", "Mónica"}
print (f"el elemento eliminado fue {sorteo.pop()}")
