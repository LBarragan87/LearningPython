mi_tuple=(1,2,3,4)
print (type(mi_tuple))

nuevo_tuple=(5,5.6,"f",True)
print (nuevo_tuple[2])

nuevo_tuple2=((10,20),(30,40),(50,60))
print(nuevo_tuple2[2][0])

x,y,z = nuevo_tuple2
print (x)