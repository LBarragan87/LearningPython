'''
Extrae los elementos de la siguiente tupla en cuatro variables: a, b, c, d

mi_tupla = (1, 2, 3, 4)
'''

mi_tupla = (1, 2, 3, 4)
a,b,c,d=mi_tupla

print (a)