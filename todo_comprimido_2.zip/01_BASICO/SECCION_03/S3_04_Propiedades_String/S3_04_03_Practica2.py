'''
Verifica si la palabra "agua" no se encuentra en el siguiente haiku. Debes imprimir el booleano.

Tierra mojada,

mis recuerdos de viaje

entre las lluvias
'''

haiku="""Tierra mojada
mis recuerdos de viaje,
entre las lluvias"""

print("agua" not in haiku)