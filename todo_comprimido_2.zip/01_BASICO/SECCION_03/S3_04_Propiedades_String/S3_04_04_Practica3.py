'''
Muestra en pantalla el largo (en números de caracteres) de la palabra electroencefalografista.
'''

print(len("electroencefalografista"))