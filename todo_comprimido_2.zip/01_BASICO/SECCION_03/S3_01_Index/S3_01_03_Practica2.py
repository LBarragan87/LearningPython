'''
Encuentra y muestra en pantalla el índice de la primera aparición de la palabra "práctica" en la siguiente frase:

"En teoría, la teoría y la práctica son los mismos. En la práctica, no lo son."
'''
frase = "En teoría, la teoría y la práctica son los mismos. En la práctica, no lo son."

print(frase.index("práctica"))