#Encuentra y muestra en pantalla qué caracter ocupa la quinta posición dentro de la siguiente palabra: "ordenador"

palabra = "ordenador"

print(palabra[4])

#opcion 2 de solucion
posicion = 5
indice = posicion-1

print(palabra[indice])