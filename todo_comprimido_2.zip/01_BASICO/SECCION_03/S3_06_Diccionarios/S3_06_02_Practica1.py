'''
Crea un diccionario llamado mi_dic que almacene la siguiente información de una persona:

nombre: Karen

apellido: Jurgens

edad: 35

ocupacion: Periodista

Los nombres de las claves y valores deben ser iguales a la consigna.
'''

mi_dic = {"nombre": "Karen","apellido": "Jurgens","edad": 35,"ocupacion": "Periodista"}