'''
Toma cada tercer caracter empezando desde el noveno hasta el final de la frase, e imprime el resultado.

"Nunca confíes en un ordenador que no puedas lanzar por una ventana"
'''

frase = "Nunca confíes en un ordenador que no puedas lanzar por una ventana"

print(frase[8::3])