'''
Extrae la primera palabra de la siguiente frase utilizando slicing, y muéstrala en pantalla:

"Controlar la complejidad es la esencia de la programación"

Pista: "Controlar" tiene un largo de 9 caracteres.
'''

frase = "Controlar la complejidad es la esencia de la programación"

print (frase[0:9])