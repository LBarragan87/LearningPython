mi_variable = "esta palabra sera extraida"
print (mi_variable[5:12])

fragmento = mi_variable[::3]
print (fragmento)

