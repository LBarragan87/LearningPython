'''
Invierte la posición de todos los caracteres de la siguiente frase y muestra el resultado en pantalla.

"Es genial trabajar con ordenadores. No discuten, lo recuerdan todo y no se beben tu cerveza"
'''
frase = "Es genial trabajar con ordenadores. No discuten, lo recuerdan todo y no se beben tu cerveza"
print(frase[::-1])