#Verifica si la raíz cuadrada de 25 es igual a 5 y muestra el resultado (booleano) en pantalla utilizando print()

import math
val1= math.sqrt(25)==5
print(val1)