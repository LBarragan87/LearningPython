#Realiza una comparación que arroje como resultado un booleano y almacena el resultado (True/False) en una variable llamada prueba

prueba=1>0