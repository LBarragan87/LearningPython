'''
booleanos True / False
forma indirecta
>
<
<=
<=
==
!=
in
not in
'''

var1 = True
print (var1)

var2 = False
print (var2)

numero = 5 == 2+3
print (numero)

mi_lista = [1,2,3,4]
print (5 in mi_lista)
print (5 not in mi_lista)