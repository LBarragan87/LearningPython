'''
Utiliza el método pop() para quitar el tercer elemento de la siguiente lista llamada frutas, y almacénalo en una variable llamada eliminado. Utiliza métodos de listas sin alterar la línea de código ya suministrada.

manzana

banana

mango

cereza

sandía
'''

frutas = ["manzana", "banana", "mango", "cereza", "sandía"]
eliminado=frutas.pop(2)