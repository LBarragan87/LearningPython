#Crea una clase llamada PlataformaStreaming y crea los siguientes objetos a partir de ella: netflix, hbo_max, amazon_prime_video

class PlataformaStreaming:
    pass

netflix=PlataformaStreaming()
hbo_max=PlataformaStreaming()
amazon_prime_video=PlataformaStreaming()