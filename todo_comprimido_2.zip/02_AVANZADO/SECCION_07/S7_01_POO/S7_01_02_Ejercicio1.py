#Crea una clase llamada Personaje y a continuación, crea un objeto a partir de ella, por ejemplo: harry_potter

class Personaje:
        pass
    
harry_potter = Personaje()