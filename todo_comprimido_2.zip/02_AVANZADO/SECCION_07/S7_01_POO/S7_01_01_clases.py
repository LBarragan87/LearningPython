'''
ejemplo de estructura de clases

class ElementoPajaro:
    pass

mi_pajaro = ElementoPajaro()
'''
import os
os.system("cls")
class Pajaro:
    pass

mi_pajaro = Pajaro()
otro_pajaro = Pajaro()


print((mi_pajaro))
print((otro_pajaro))