#Crea una clase llamada Dinosaurio, y tres instancias a partir de ella: velociraptor, tiranosaurio_rex y braquiosaurio .

class Dinosaurio:
    pass

velociraptor=Dinosaurio()
tiranosaurio_rex=Dinosaurio()
braquiosaurio =Dinosaurio()