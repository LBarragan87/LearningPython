'''
Crea una clase Perro. Dicho perro debe poder ladrar.

Crea el método ladrar() y ejecútalo en una instancia de Perro. Cada vez que ladre, debe mostrarse en pantalla "Guau!".
'''

import os
os.system("cls")

class Perro:
    def ladrar(self):
        print("Guau!")
        
mi_perro = Perro()
mi_perro.ladrar()