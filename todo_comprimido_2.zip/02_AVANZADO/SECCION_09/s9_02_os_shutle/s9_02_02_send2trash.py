import send2trash


send2trash.send2trash("curso.txt")
