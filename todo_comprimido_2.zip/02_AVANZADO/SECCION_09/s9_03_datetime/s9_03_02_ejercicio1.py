'''
Crea un objeto fecha llamado mi_fecha que almacene el día 3 de febrero de 1999
'''
import datetime
mi_fecha = datetime.date(1999, 2, 3)

print(mi_fecha)
