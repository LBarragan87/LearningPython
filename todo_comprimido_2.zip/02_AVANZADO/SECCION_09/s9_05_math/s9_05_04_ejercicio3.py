'''
Encuentra el factorial de 7 y almacena el resultado en la variable resultado.

El método a utilizar es factorial()
'''
import math
resultado = math.factorial(7)

print(resultado)

