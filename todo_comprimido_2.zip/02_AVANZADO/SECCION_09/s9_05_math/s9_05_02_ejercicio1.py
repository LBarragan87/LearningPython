'''
Obtén el logaritmo base 10 del número 25, y almacena el resultado en la
variable resultado.

Puedes utilizar el método math.log10()

Puedes consultar el enlace anterior si quieres conocer más acerca del
logaritmo decimal.
'''
import math


resultado = math.log10(25)

print(resultado)
