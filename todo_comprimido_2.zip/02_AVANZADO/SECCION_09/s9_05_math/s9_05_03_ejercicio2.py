'''
Obten la raíz cuadrada de pi con la constante math.pi y el método math.sqrt().
Almacena el resultado obtenido en la variable resultado.
'''
import math


resultado = math.sqrt(math.pi)

print(resultado)
