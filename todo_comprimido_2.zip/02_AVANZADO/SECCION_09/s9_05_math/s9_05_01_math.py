import math

resultado = math.pi

print(resultado)

x = 27
y = 3
z = math.log(x, y)
print(z)
