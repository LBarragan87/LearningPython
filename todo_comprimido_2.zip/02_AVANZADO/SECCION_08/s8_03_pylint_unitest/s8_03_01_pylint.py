# test 8

def una_funcion():
    numero1 = 500
    print(numero1)


una_funcion()
