def hola():
    print("hey!")