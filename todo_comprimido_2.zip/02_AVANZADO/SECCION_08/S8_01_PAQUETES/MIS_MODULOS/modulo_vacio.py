import os
from modulo_ocupado import *


os.system("cls")
saludar()